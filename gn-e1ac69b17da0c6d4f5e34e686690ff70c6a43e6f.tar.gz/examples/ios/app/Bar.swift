
import Baz;

public class Greeter {
  public static func greet(greeting: String, name: String, from: String) -> String {
    return greeting + ", " + name + " (from " + from + ")";
  }
}
